exports.handler = async (event) => {
    let response;
    try {
        const data = JSON.parse(event.body);
        const text = data.text || "";

        // Example logic: word count
        const wordCount = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;

        // Proper Lambda proxy response
        response = {
            statusCode: 200,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text, wordCount })
        };
    } catch (err) {
        response = {
            statusCode: 500,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ error: err.message })
        };
    }

    return response;
};